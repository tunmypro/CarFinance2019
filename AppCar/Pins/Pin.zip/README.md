---
name: Map Custom Renderer
description: This sample demonstrates how to create a custom renderer for the `Map` control, which displays a native map with a customized pin and a customized ...
topic: sample
languages:
- csharp
products:
- xamarin
technologies:
- xamarin-forms
urlFragment: customrenderers-map-pin
---
Map Custom Renderer
===================

This sample demonstrates how to create a custom renderer for the `Map` control, which displays a native map with a customized pin and a customized view of the pin data on each platform.

For more information about this sample see [Customizing a Map Pin](http://developer.xamarin.com/guides/xamarin-forms/custom-renderer/map/customized-pin/).

Author
------

David Britch
